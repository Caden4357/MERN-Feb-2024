
function App() {
  return (
    <div className="container">
      <h1>hello world</h1>
      <p>Test</p>
    </div>
  )
}

export default App
